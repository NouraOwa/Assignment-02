import Foundation

// Create empty array of type Int
var array : [Int] = []

// add five values to the array
array1 = [1, 2, 3, 4, 5]

// Use a for-in loop to iterate through the array
for i in array1{
    print(i)
}

// Create a dictionary with string keys and integer values
var dic : [String : Int] = ["A+" : 100, "A" : 9, "B" : 89]

// Use a for-in loop to iterate through the dictionary
for i in dic{
    print(i)
}

// Create a while loop that counts up to 100
var num = 0
while num <= 100{
    print(num)
    num += 1
}

// Create a repeat-while loop that counts down from 10
var num1 = 0
repeat {
    print(num1)
    num1 += 1
}while num1 <= 10

// Use a for-in loop to iterate through a range of numbers
for _ in 0...5{
    print("Hello")
}

// Use a for-in loop to iterate through a range of numbers with a step
//: OUTPUT
/*
 0
 2
 4
 6
 8
 */
for i in stride (from: 0, to: 10, by: 2){
    print(i)
}

// Create an array of strings and use a for-in loop to print each one
var array2: [String] = ["apple", "orange", "Avocado"]
for i in array2{
    print(i)
}

// Use a for-in loop with the enumerated() method to iterate through an array and print the index and value of each element
let fruits = ["Banana", "Pinapple", "Lemon"]
        
fruits.enumerated().forEach { (index, name) in
    print("\(index): \(name)")
}

/*
 Write a swift program to formulate this shape
 😃
 😃😃
 😃😃😃
 😃😃😃😃
 😃😃😃😃😃
 */
var array3 = ["😃", "😃😃", "😃😃😃", "😃😃😃😃", "😃😃😃😃😃"]
for i in array3{
    print(i)
}
